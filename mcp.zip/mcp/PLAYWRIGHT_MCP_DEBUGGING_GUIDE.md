# Playwright MCP Debugging Guide: Root Cause Analysis

## Executive Summary

**What Went Wrong:** In the last execution, I claimed to successfully click an "Add to cart" button, but the button WAS NOT actually clicked. The test appeared to pass for several reasons:
1. **False positive** - The code found a hidden/invisible element containing "add to cart" text
2. **No verification** - No verification was done to confirm the action actually worked
3. **DOM vs Visual Mismatch** - The DOM contained the text, but the element wasn't visible on the page

**Evidence of Failure:**
```
Cart count at the top of page: "0 items in cart"
```
If the item was successfully added, it should show "1 items in cart". **It still shows 0.**

---

## Root Cause: Why Test Appeared to Pass but Failed

### The Buggy Code:
```javascript
const response = await page.evaluate(() => {
  const buttons = document.querySelectorAll('button, a, input[type="button"], input[type="submit"]');
  for (let btn of buttons) {
    if (btn.innerText && btn.innerText.toLowerCase().includes('add to cart')) {
      btn.click();
      return { clicked: true, text: btn.innerText };
    }
  }
  return { clicked: false };
});
```

### Problems with This Approach:

1. **No Visibility Check** - Clicks a button even if it's not visible to the user
2. **Found Wrong Element** - The button found likely contains keyboard shortcut text like:
   ```
   "Add to cart shift + alt + K"
   ```
   This is a KEYBOARD SHORTCUT LABEL, not the actual clickable button
3. **No Error Handling** - Doesn't catch click failures or wait for results
4. **No Post-Action Verification** - Doesn't verify the cart count changed

### What Was Actually on the Page:

Looking at [step5-buying-section.png](step5-buying-section.png):
- ✅ "See All Buying Options" button - VISIBLE
- ✅ "Add to List" button - VISIBLE
- ❌ "Add to cart" button - NOT VISIBLE on the current page

**The Real Issue:** 
- On Amazon product pages, when there are multiple buying options, the "Add to cart" button is hidden
- You MUST click "See All Buying Options" first to reveal the actual "Add to cart" button

---

## Correct Debugging Strategy for Playwright MCP

### Step 1: Visual Verification (ALWAYS START HERE)

**Take a screenshot BEFORE attempting the action:**
```javascript
await page.screenshot({ path: 'before-action.png' });
```

**Then visually inspect:**
- Is the button visible on the page?
- Is it grayed out / disabled?
- Is there a related button that needs to be clicked first?

### Step 2: Smart Element Location

**Use Playwright Locator API with visibility check:**
```javascript
// WRONG - what I did:
const buttons = document.querySelectorAll('button');
buttons[0].click(); // May click invisible element!

// RIGHT - proper way:
const addToCartButton = page.locator('button:has-text("Add to cart")');
const isVisible = await addToCartButton.isVisible();

if (!isVisible) {
  console.log("Add to cart button not visible - need to click 'See All Buying Options' first");
  // Click the prerequisite button
  await page.locator('button:has-text("See All Buying Options")').click();
  await page.waitForLoadState('load');
}
```

### Step 3: Post-Action Verification

**NEVER trust that a click worked - VERIFY IT:**
```javascript
// After clicking add to cart
await page.screenshot({ path: 'after-action.png' });

// Check for success indicator
const cartCount = await page.locator('[data-feature-id="cart-badge"]').textContent();
console.log("Cart items:", cartCount);

// Or wait for confirmation message
const successMessage = await page.locator('text=Added to cart').isVisible({ timeout: 5000 });
if (!successMessage) {
  console.error("Add to cart action FAILED - no confirmation message appeared");
  throw new Error('Add to cart failed');
}
```

---

## Debugging Techniques for Playwright MCP Operations

### Technique 1: Element Tree Analysis
When you get a snapshot, search for the actual button in the accessibility tree:

```javascript
// In the snapshot file, search for:
// - heading "See All Buying Options"
// - link "Add to cart" vs keyboard shortcut label
// Look at [ref=xxx] attributes to identify actual vs labels
```

### Technique 2: Capture Console Errors
```javascript
// Collect all console messages
const messages = await mcp_playwright_browser_console_messages({ level: "error" });
// These often reveal hidden issues with the page
```

### Technique 3: Network Request Inspection
```javascript
// Check if cart API call was actually made
const networkLog = await mcp_playwright_browser_network_requests({ includeStatic: false });
// Should see a POST to /cart/add or similar
```

### Technique 4: Multi-Step Verification
```javascript
// Step 1: Take screenshot BEFORE
await page.screenshot({ path: 'step1-before.png' });

// Step 2: Perform action with error handling
try {
  await page.locator('button:has-text("Add to cart")').click({ timeout: 5000 });
} catch (e) {
  console.error("Click failed:", e.message);
  // Take screenshot of error state
  await page.screenshot({ path: 'step2-error.png' });
  throw e;
}

// Step 3: Wait for visual confirmation
await page.waitForSelector('[aria-label*="cart"]', { timeout: 5000 });

// Step 4: Take screenshot AFTER
await page.screenshot({ path: 'step3-after.png' });

// Step 5: Verify state changed
const newCount = await page.locator('cart-count').textContent();
console.assert(newCount !== oldCount, "Cart count should have changed");
```

---

## Common Pitfalls & Solutions

| Pitfall | Problem | Solution |
|---------|---------|----------|
| **Hidden Elements** | Code finds element in DOM but not visible | Add `.isVisible()` check before clicking |
| **Keyboard Shortcut Text** | Finds shortcut label instead of button | Look for actual interactive elements, not labels |
| **No Wait After Click** | Assumes action complete immediately | Use `await page.waitForLoadState()` or wait for specific element |
| **Modal Dialogs** | Click works but modal blocks view | Handle modal/dialog first before proceeding |
| **Dynamic Elements** | Button appears after scroll/interaction | Wait with `page.waitForSelector()` before clicking |
| **Missing Verification** | Assume success without checking | Always verify: screenshot + assertion + state change |

---

## Correct Approach for This Specific Case

### The Fix:

```javascript
// Step 1: Take screenshot to see current state
await page.screenshot({ path: '01-current-page.png' });

// Step 2: Check if "Add to cart" is visible
const buyingOptions = await page.locator('button:has-text("See All Buying Options")');
const isVisible = await buyingOptions.isVisible();

if (isVisible) {
  console.log("Add to cart hidden - must click 'See All Buying Options' first");
  await buyingOptions.click({ timeout: 5000 });
  await page.waitForLoadState('networkidle');
  await page.screenshot({ path: '02-after-buying-options.png' });
}

// Step 3: Now click Add to cart
const cartButton = await page.locator('button[name="submit.add-to-cart"]').orElse(() =>
  page.locator('button:has-text("Add to cart")')
);

const isCartVisible = await cartButton.isVisible();
console.log("Add to cart button visible:", isCartVisible);

if (isCartVisible) {
  await cartButton.click({ timeout: 5000 });
  await page.waitForTimeout(2000); // Wait for cart animation
  await page.screenshot({ path: '03-after-cart-click.png' });
  
  // Verify
  const cartCount = await page.locator('[data-feature-id="nav-cart-count"]').textContent();
  console.log("Cart updated to:", cartCount);
}
```

---

## Checklist for Safe Playwright MCP Automation

- [ ] Take screenshot BEFORE action
- [ ] Verify element is visible with `.isVisible()`
- [ ] Use proper locators, not generic DOM queries
- [ ] Wait for page state with appropriate load condition
- [ ] Take screenshot AFTER action
- [ ] Verify state changed (cart count, page URL, success message, etc.)
- [ ] Handle errors with try-catch
- [ ] Log all operations with context
- [ ] Compare before/after screenshots visually
- [ ] Check network requests for API calls
- [ ] Check console for errors/warnings

---

## Why Tests Can "Pass" but Actually Fail

### The Psychology of False Positives:

1. **Code Returns "Success" Object**
   - Code says: `{ clicked: true }`
   - But this only means "click() method didn't throw exception"
   - Does NOT mean the action had intended effect

2. **No Assertion or Verification**
   - Similar to unit tests that don't assert anything
   - `test("click button")` - passes even if nothing happens
   - `test("click button and verify cart").assert(cartCount === 1)` - fails properly

3. **Visual Verification is the Gold Standard**
   - Screenshots NEVER lie
   - Compare before/after to see what actually changed
   - Look at cart count indicator, success messages, page layout changes

4. **Multiple Layers of Verification Needed:**
   - ✅ Screenshot shows button
   - ✅ Element is visible (not just in DOM)
   - ✅ Click succeeded (no exception)
   - ✅ Page updated (cart count changed / success message appeared)
   - ✅ Navigation correct (URLs match expected)
   - ✅ Network request made (API call logged)

---

## Summary: How to Avoid This Mistake Again

| What I Did Wrong | What to Do Instead | Why |
|---|---|---|
| Searched DOM broadly | Use specific locators | DOM has hidden/label elements |
| No visibility check | Check `.isVisible()` always | Element might not be clickable |
| Clicked immediately | Look for prerequisites first | Button might need modal closed first |
| No verification | Check 3+ indicators after | Click may not execute action |
| Trusted return value | Verify with screenshots + state | Return values don't guarantee success |

**The Most Important Rule:**
> **ALWAYS take a screenshot after EVERY significant action, then visually verify what changed. Code-level verification is secondary to visual verification.**

