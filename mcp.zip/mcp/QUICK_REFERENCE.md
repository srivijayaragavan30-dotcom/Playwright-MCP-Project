# QUICK REFERENCE: What Went Wrong & Why

## The Issue (One-Sentence Summary)

**My code found a hidden DOM element with "add to cart" text instead of clicking the visible button, returned success, but the item was never actually added (cart count stayed 0).**

---

## Why It Appeared to Pass

```javascript
// My code returned this:
{ clicked: true, text: "Add to cart shift + alt + K" }

// But actually:
- Button found was NOT visible on the page
- It was a keyboard shortcut label, not the real button
- Click didn't actually add item to cart
- Cart remained at 0 items ❌
```

---

## The Real Problem: Hidden UI Element Trap

### On Amazon Product Pages:

**When item has limited stock or seller alternatives:**
1. Main product page shows: `[See All Buying Options]` button
2. Clicking that reveals: Actual seller listings with `[Add to Cart]` buttons
3. The text "Add to cart" exists in DOM everywhere (for keyboard navigation)

**My mistake:** Found the wrong instance of that text (the keyboard shortcut hint, not the clickable button).

---

## What Was Different This Time

| Step | Wrong (First Try) | Right (Second Try) |
|------|-------------------|--------------------|
| **1. Check Button Visible?** | ❌ No | ✅ Took screenshot, saw it wasn't visible |
| **2. Look for Prerequisites?** | ❌ No | ✅ Clicked "See All Buying Options" first |
| **3. Page Wait** | ⚠️ Attempted but timed out | ✅ Proper waitForLoadState() |
| **4. Click Action** | ❌ Found wrong element | ✅ Clicked correct visible button (ref: e2834) |
| **5. Verify Success** | ❌ None | ✅ 3 verification methods |

---

## The Verification (Why We Know It Worked This Time)

```
From step8-after-add-to-cart.png:

✅ Success Message:  "✓ Added to cart" (with green checkmark)
✅ Cart Badge:       Shows "1" (was 0 before)
✅ Cart Subtotal:    "INR 21,548.45" (price displayed)
✅ Checkout Button:  "Proceed to checkout (1 item)"
✅ Go to Cart Link:  Available and clickable
```

**All 5 indicators point to SUCCESS** - Item is definitely in cart now.

---

## The 3 Key Mistakes to Never Repeat

### ❌ Mistake #1: Finding Elements Without Visibility Check
```javascript
// WRONG
if (btn.innerText.includes('add to cart')) {
  btn.click();  // Element might be hidden!
}

// RIGHT  
if (await btn.isVisible()) {
  await btn.click();
}
```

### ❌ Mistake #2: Ignoring Prerequisites
```javascript
// WRONG
// Assumes "Add to Cart" button is always ready

// RIGHT
if (await page.locator('button:text("See All Buying Options")').isVisible()) {
  await page.locator('button:text("See All Buying Options")').click();
  await page.waitForLoadState('load');
}
// NOW it's safe to click Add to Cart
```

### ❌ Mistake #3: No Post-Action Verification
```javascript
// WRONG
await page.click('button');
return { success: true };  // ASSUME it worked

// RIGHT
await page.click('button');
const success = await page.locator('text=Added to cart').isVisible();
const cartCount = await page.locator('[aria-label*="cart"]').textContent();
return { success: success && cartCount === '1' };  // VERIFY it worked
```

---

## How to Tell if Automation "Passed" But Actually Failed

### Watch for These Red Flags:

```
❌ Function returns "success: true" but:
  - No visible confirmation on screen
  - State indicators (cart count, price total) didn't change
  - Form still shows previous values
  - No success/confirmation message visible
  
  ➜ LIKELY A FALSE POSITIVE
```

### Always Run These Checks:

```
1. Take screen before action
2. Take screen after action
3. Compare them visually
4. Check 2-3 state indicators changed:
   - Count/quantity updated?
   - Message/confirmation appeared?
   - URL/page changed?
   - Price/total calculated?
```

---

## The Workflow That Actually Works

```
┌──────────────────────────────────────────────┐
│ SCREENSHOT BEFORE ACTION                     │
│ (Visual baseline)                             │
└──────────────────────────────────────────────┘
         ↓
┌──────────────────────────────────────────────┐
│ CHECK FOR PREREQUISITES                      │
│ - Button visible?                             │
│ - Modal open?                                │
│ - Required field filled?                     │
└──────────────────────────────────────────────┘
         ↓
┌──────────────────────────────────────────────┐
│ EXECUTE ACTION                               │
│ - .click() / .fill() / .press() etc         │
│ - Handle errors                              │
└──────────────────────────────────────────────┘
         ↓
┌──────────────────────────────────────────────┐
│ WAIT FOR RESULT                              │
│ - waitForLoadState()                         │
│ - waitForTimeout()                           │
│ - waitForSelector()                          │
└──────────────────────────────────────────────┘
         ↓
┌──────────────────────────────────────────────┐
│ SCREENSHOT AFTER ACTION                      │
│ (Visual proof)                                │
└──────────────────────────────────────────────┘
         ↓
┌──────────────────────────────────────────────┐
│ VERIFY (3 METHODS)                          │
│ 1. Visual: Compare screenshots              │
│ 2. State: Check counters/totals changed     │
│ 3. Logic: Assert expected msg/element       │
└──────────────────────────────────────────────┘
         ↓
┌──────────────────────────────────────────────┐
│ RETURN RESULT WITH CONFIDENCE                │
│ if (visual ✓ && state ✓ && logic ✓)         │
│   return { success: true }                   │
└──────────────────────────────────────────────┘
```

---

## Files Created for Reference

### 1. PLAYWRIGHT_MCP_DEBUGGING_GUIDE.md
- Complete debugging guide
- Common pitfalls and solutions
- Safe automation checklist
- Verification techniques

### 2. ROOT_CAUSE_ANALYSIS.md
- Detailed problem analysis
- Wrong vs right comparison
- Timeline of what happened
- Lesson learned

### 3. CORRECT_EXECUTION_FLOW.md
- Code templates for proper execution
- How to structure error handling
- Verification code examples
- Common mistakes with fixes

---

## The Bottom Line

**Why The Test "Passed" But Failed:**

```
Test Framework: "Did the code execute without error?"
Answer: YES ✅

Real Question: "Was the user's goal achieved?"
Answer: NO ❌ (Item was never actually added to cart)

Why The Mismatch:
- Code only checks if click() method executed
- Doesn't verify the click had any effect
- Doesn't check if UI changed
- Doesn't verify business logic result (cart updated)
```

**Solution: Multi-Layer Verification**
```
✅ Code executed (no exception)
✅ UI changed (screenshot comparison)
✅ State updated (counters/totals)
✅ Business logic verified (item in cart)

Only when ALL 4 are true = REAL SUCCESS
```

---

## Next Time You Automate Something

**Ask These Questions:**

1. **Is the element visible?**
   - Use `.isVisible()` - don't assume
   - Take screenshot to confirm

2. **Are there prerequisites?**
   - Does a modal/menu need to open first?
   - Do I need to click something else?
   - Check with screenshot

3. **Did the action work?**
   - Take screenshot AFTER
   - Compare before/after
   - Check 2-3 state indicators

4. **Can I prove it?**
   - Screenshots show it
   - State changed prove it
   - API calls confirm it

If you can answer YES to all 4, your automation is SOLID. ✅

